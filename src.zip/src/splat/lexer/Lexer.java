package splat.lexer;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Lexer {
    private final File sourceFile;

    public Lexer(File progFile) {
        this.sourceFile = progFile;
    }

    public List<Token> tokenize() throws LexException {
        List<Token> tokens = new ArrayList<>();

        try (BufferedReader buffReader = new BufferedReader(new FileReader(sourceFile))) {
            int charCode;
            int line = 1;
            int col = 0;

            while ((charCode = buffReader.read()) != -1) {
                char currentChar = (char) charCode;
                col++;

                if (currentChar == ' ' || currentChar == '\t' || currentChar == '\r') continue;

                if (currentChar == '\n') {
                    line++;
                    col = 0;
                    continue;
                }

                if (currentChar == '/') {
                    buffReader.mark(2);
                    int peek1 = buffReader.read();
                    if (peek1 == '/') {
                        while ((charCode = buffReader.read()) != -1 && charCode != '\n') {}
                        line++;
                        col = 0;
                        continue;
                    } else if (peek1 == '*') {
                        boolean closed = false;
                        int prevChar = 0;
                        while ((charCode = buffReader.read()) != -1) {
                            char cc = (char) charCode;
                            if (cc == '\n') {
                                line++;
                                col = 0;
                            } else {
                                col++;
                            }
                            if (prevChar == '*' && cc == '/') {
                                closed = true;
                                break;
                            }
                            prevChar = cc;
                        }
                        if (!closed)
                            throw new LexException("Unterminated comment", line, col);
                        continue;
                    } else {
                        buffReader.reset();
                        tokens.add(new Token("/", line, col));
                        continue;
                    }
                }

                if (currentChar == '"') {
                    StringBuilder buffer = new StringBuilder();
                    int startCol = col;
                    boolean closed = false;
                    while ((charCode = buffReader.read()) != -1) {
                        char cc = (char) charCode;
                        if (cc == '\n') throw new LexException("Unterminated string literal", line, startCol);
                        if (cc == '"') { closed = true; break; }
                        if (cc == '\\') {
                            int esc = buffReader.read();
                            if (esc == -1) throw new LexException("Invalid escape sequence", line, startCol);
                            switch (esc) {
                                case 'n': buffer.append('\n'); break;
                                case 't': buffer.append('\t'); break;
                                case '"': buffer.append('"'); break;
                                case '\\': buffer.append('\\'); break;
                                default:
                                    throw new LexException("Invalid escape sequence: \\" + (char) esc, line, startCol);
                            }
                        } else buffer.append(cc);
                        col++;
                    }
                    if (!closed)
                        throw new LexException("Unterminated string literal", line, startCol);
                    tokens.add(new Token('"' + buffer.toString() + '"', line, startCol));
                    continue;
                }

                if (currentChar == '\'') {
                    int startCol = col;
                    buffReader.mark(3);
                    int first = buffReader.read();
                    if (first == -1 || first == '\n' || first == '\'')
                        throw new LexException("Invalid char literal", line, startCol);

                    if (first == '\\') {
                        int esc = buffReader.read();
                        if (esc == -1 || esc == '\n')
                            throw new LexException("Invalid char escape sequence", line, startCol);
                        int closing = buffReader.read();
                        if (closing != '\'')
                            throw new LexException("Invalid char literal", line, startCol);
                        switch (esc) {
                            case 'n': case 't': case '\\': case '\'': break;
                            default:
                                throw new LexException("Invalid char escape sequence: \\" + (char) esc, line, startCol);
                        }
                        tokens.add(new Token("'\\"
                                + (char) esc + "'", line, startCol));
                        continue;
                    } else {
                        int closing = buffReader.read();
                        if (closing != '\'')
                            throw new LexException("Invalid char literal", line, startCol);
                        tokens.add(new Token("'" + (char) first + "'", line, startCol));
                        continue;
                    }
                }

                if (Character.isLetter(currentChar) || currentChar == '_') {
                    StringBuilder sb = new StringBuilder();
                    int startCol = col;
                    sb.append(currentChar);
                    buffReader.mark(1);
                    while ((charCode = buffReader.read()) != -1) {
                        char cc = (char) charCode;
                        if (Character.isLetterOrDigit(cc) || cc == '_') {
                            sb.append(cc);
                            col++;
                            buffReader.mark(1);
                        } else {
                            buffReader.reset();
                            break;
                        }
                    }
                    tokens.add(new Token(sb.toString(), line, startCol));
                    continue;
                }

                if (Character.isDigit(currentChar)) {
                    StringBuilder sb = new StringBuilder();
                    int startCol = col;
                    sb.append(currentChar);
                    buffReader.mark(1);
                    while ((charCode = buffReader.read()) != -1) {
                        char cc = (char) charCode;
                        if (Character.isDigit(cc)) {
                            sb.append(cc);
                            col++;
                            buffReader.mark(1);
                        } else {
                            buffReader.reset();
                            break;
                        }
                    }
                    tokens.add(new Token(sb.toString(), line, startCol));
                    continue;
                }

                buffReader.mark(2);
                int peek2 = buffReader.read();
                int peek3 = buffReader.read();
                if (peek2 != -1 && peek3 != -1) {
                    String tripleOp = "" + currentChar + (char) peek2 + (char) peek3;
                    if (tripleOp.equals("<==") || tripleOp.equals(">==") || tripleOp.equals("!==")) {
                        throw new LexException("Unknown character sequence: " + tripleOp, line, col);
                    }
                    buffReader.reset();
                } else {
                    buffReader.reset();
                }

                buffReader.mark(1);
                int next = buffReader.read();
                if (next != -1) {
                    String doubleOp = "" + currentChar + (char) next;
                    if (doubleOp.equals("==") || doubleOp.equals("!=") || doubleOp.equals("<=") || doubleOp.equals(">=")
                            || doubleOp.equals("&&") || doubleOp.equals("||") || doubleOp.equals("->")) {
                        tokens.add(new Token(doubleOp, line, col));
                        col++;
                        continue;
                    } else buffReader.reset();
                }

                if (currentChar == '\\')
                    throw new LexException("Unknown character: \\", line, col);

                if ("#@$^~`|?".indexOf(currentChar) != -1)
                    throw new LexException("Unknown character: " + currentChar, line, col);

                String singleOp = String.valueOf(currentChar);
                if (";:,(){}[]+-*/<>=.".contains(singleOp)) {
                    tokens.add(new Token(singleOp, line, col));
                    continue;
                }

                if (currentChar < 32 || currentChar > 126)
                    throw new LexException("Unknown character: " + currentChar, line, col);

                throw new LexException("Unknown character: " + currentChar, line, col);
            }

        } catch (IOException e) {
            throw new LexException("I/O error: " + e.getMessage(), 0, 0);
        }

        return tokens;
    }
}